package kr.ac.dankook.mobile.bspark.assignmentweek8

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameTxt = findViewById<TextView>(R.id.usernameTxt)
        val passwordTxt = findViewById<TextView>(R.id.passwordTxt)
        val loginBtn = findViewById<Button>(R.id.loginBtn)

        val sharedPref = getSharedPreferences("kr.ac.dankook.mobile.bspark.SHARED_PREF", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        val username:String? = sharedPref.getString("username", "unknown")
        val password:String? = sharedPref.getString("password", "****")
        val id = sharedPref.getInt("id", -1)

        if (id == -1){
            Log.d("DKMobile", "No Username and PW at Shared Preferences!!")
        }
        else{
            usernameTxt.setText(username)
            passwordTxt.setText(password)
            Log.d("DKMobile", "Username and PW are already at Shared Preferences!!")
        }

        loginBtn.setOnClickListener{
            val usrN = usernameTxt.getText().toString()
            val pw = passwordTxt.getText().toString()
            editor.putString("username", usrN)
            editor.putString("password", pw)
            editor.putInt("id", 1)
            editor.apply()
            Log.d("DKMobile", "Username and PW are stored at Shared Preferences!!")
        }
    }
}