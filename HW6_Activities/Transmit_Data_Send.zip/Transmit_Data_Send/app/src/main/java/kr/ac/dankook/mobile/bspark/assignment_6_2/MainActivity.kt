package kr.ac.dankook.mobile.bspark.assignment_6_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val intentMain = Intent(this, SubActivity::class.java)

        val num1 = findViewById<EditText>(R.id.num1)
        val num2 = findViewById<EditText>(R.id.num2)
        val calBtn = findViewById<Button>(R.id.calBtn)

        calBtn.setOnClickListener {
            intentMain.putExtra("num1", num1.getText().toString().toInt())
            intentMain.putExtra("num2", num2.getText().toString().toInt())
            startActivity(intentMain)
        }
    }
}