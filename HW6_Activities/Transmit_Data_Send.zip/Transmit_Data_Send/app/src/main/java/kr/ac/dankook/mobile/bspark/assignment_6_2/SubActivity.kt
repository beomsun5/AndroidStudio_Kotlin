package kr.ac.dankook.mobile.bspark.assignment_6_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)

        val intentSub = intent

        val num1 = intentSub.getIntExtra("num1", 0)
        val num2 = intentSub.getIntExtra("num2", 0)

        val resultTxt = findViewById<TextView>(R.id.resultTxt)
        val result = num1.toString() + '+' + num2.toString() + '=' + (num1+num2).toString()
        resultTxt.setText(result)

        val rtnBtn = findViewById<Button>(R.id.rtnBtn)
        rtnBtn.setOnClickListener {
            finish()
        }
    }
}