package kr.ac.dankook.mobile.bspark.assignmentweek8_2

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.room.Room

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameTxt = findViewById<TextView>(R.id.usernameTxt)
        val passwordTxt = findViewById<TextView>(R.id.passwordTxt)
        val loginBtn = findViewById<Button>(R.id.loginBtn)

        val db = Room.databaseBuilder(
            applicationContext,
            UserDB::class.java, "userdb"
        ).allowMainThreadQueries().build()

        val users = db.userDao().getAll()
        val dbSize = users.size
        Log.d("USERDB", "Current DB Size : $dbSize")

        if(users.isNotEmpty()) {
            val userUID = users[dbSize-1].uid
            val userID = users[dbSize-1].id
            val userPW = users[dbSize-1].pw
            Log.d("USERDB", "Something in db")
            usernameTxt.setText(userID)
            passwordTxt.setText(userPW)
        } else {
            Log.d("USERDB", "Nothing in db")
        }

        loginBtn.setOnClickListener{
            val usrN = usernameTxt.getText().toString()
            val pw = passwordTxt.getText().toString()
            val userD = User(dbSize, usrN, pw)
            db.userDao().insertAll(userD)
            Log.d("USERDB", "Username and PW are stored at db!!")
        }
    }
}