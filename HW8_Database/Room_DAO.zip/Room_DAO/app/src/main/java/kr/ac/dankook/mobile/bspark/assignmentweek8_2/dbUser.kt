package kr.ac.dankook.mobile.bspark.assignmentweek8_2

import androidx.room.*

@Entity(tableName="users")
data class User(
    @PrimaryKey val uid: Int,
    @ColumnInfo(name = "userN") val id: String?,
    @ColumnInfo(name = "passW") val pw: String?
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getAll(): List<User>

    @Query("SELECT * FROM users WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray): List<User>

    @Query("SELECT * FROM users WHERE userN LIKE :id AND " +
    "passW LIKE :pw LIMIT 1")
    fun findByName(id: String, pw: String): User

    @Insert
    fun insertAll(vararg users: User)

    @Delete
    fun delete(users: User)

    @Delete
    fun deleteAll(users: List<User>)
}

@Database(entities = arrayOf(User::class), version=2)
abstract class UserDB : RoomDatabase() {
    abstract fun userDao(): UserDao
}