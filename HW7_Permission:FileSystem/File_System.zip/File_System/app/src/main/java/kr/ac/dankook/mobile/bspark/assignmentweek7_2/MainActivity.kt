package kr.ac.dankook.mobile.bspark.assignmentweek7_2

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*
        val fileName = "internal.txt"
        val fileBody = "File for testing"
        val buffo = applicationContext.openFileOutput(fileName, Context.MODE_PRIVATE)
        buffo.write(fileBody.toByteArray())
        buffo.close()

        val buffi = applicationContext.openFileInput(fileName)
        val buffr = buffi.bufferedReader()
        var txt = buffr.readLine()
        buffr.close()
        Log.d("FILETEST", "---> $txt")
         */
        val btnWR = findViewById<Button>(R.id.btnWR)
        val txt = findViewById<TextView>(R.id.textView)
        val fileName = "internal.txt"
        var fileBody = ""

        var i = 0

        btnWR.setOnClickListener {
            if (btnWR.text == "WRITE"){
                btnWR.text = "READ"
                txt.setText("New number written to file")
                fileBody = "File for testing " + i.toString()
                // Write the text file
                applicationContext.openFileOutput(fileName, Context.MODE_PRIVATE).use {
                    it.write(fileBody.toByteArray())
                    it.close()
                    i += 1
                }
            }
            else{
                btnWR.text = "WRITE"
                // Read the text file
                applicationContext.openFileInput(fileName).use {
                    var getTxt = it.bufferedReader().readLine()
                    txt.setText(getTxt)
                    Log.d("FILETEST", "---> $getTxt")
                    it.close()
            }
        }
        }
    }
}