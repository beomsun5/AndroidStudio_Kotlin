package kr.ac.dankook.mobile.bspark.assignmentweek7

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnCamera = findViewById<Button>(R.id.idbtnCamera)
        val text = findViewById<TextView>(R.id.textView)

        // Show the permission status when the app started
        val cameraPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
        if (cameraPermission == PackageManager.PERMISSION_GRANTED){
            text.setText("CAMERA permission already granted")
            Log.d("DKMOBILE", "CAMERA permission already granted!")
            // Do Something!
        }
        else{
            text.setText("CAMERA Permission not granted")
            Log.d("DKMOBILE", "CAMERA Permission not granted")
        }

        btnCamera.setOnClickListener {
            Log.d("DKMobile", "CAMERA button pressed.")
            if (cameraPermission == PackageManager.PERMISSION_GRANTED){
                text.setText("CAMERA permission already granted!!!")
                Log.d("DKMOBILE", "CAMERA permission already granted!")
                // Do Something!
            }
            else{
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 99)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        val text = findViewById<TextView>(R.id.textView)
        when(requestCode){
            99 -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    text.setText("CAMERA Permission granted now")
                    Log.d("DKMOBILE", "CAMERA Permission newly granted now")
                    // Do something when user grant information
                }
                else {
                    text.setText("CAMERA Permission not granted")
                    Log.d("DKMOBILE", "CAMERA Permission not granted")
                    // Do something when user not grant information
                }
            }
        }
    }
}