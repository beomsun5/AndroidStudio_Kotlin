package kr.ac.dankook.mobile.bspark.assignment_6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)

        Log.d("DKMobile", "Sub Activity created!")

        val rtnBtn = findViewById<Button>(R.id.rtnBtn)
        rtnBtn.setOnClickListener {
            Log.d("DKMobile", "BACK button pressed.")
            finish()
        }
    }
}