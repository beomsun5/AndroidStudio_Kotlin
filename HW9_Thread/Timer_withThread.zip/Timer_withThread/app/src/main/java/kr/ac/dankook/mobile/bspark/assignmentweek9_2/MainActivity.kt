package kr.ac.dankook.mobile.bspark.assignmentweek9_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.widget.Button
import android.widget.TextView

var started = false

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val timerText = findViewById<TextView>(R.id.timerText)
        val buttonStart = findViewById<Button>(R.id.buttonStart)
        val buttonStop = findViewById<Button>(R.id.buttonStop)

        val myHandler = object : Handler(Looper.getMainLooper()){
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)
                Log.d("TimerThread", "Main Thread")
                if(msg.what == 1){
                    // Update timerText.text
                    timerText.setText("%02d:%02d".format(msg.arg2,msg.arg1))
                }
            }
        }

        Thread{
            var i = 0
            while(true){
                var msg = myHandler.obtainMessage()
                Thread.sleep(1000)
                if(started){
                    i += 1
                    msg.what = 1
                    if (i == 6000) i = 0
                    msg.arg1 = i % 60
                    msg.arg2 = i / 60
                    Log.d("TimerThread", "In background thread -> %02d min : %02d sec".format(i/60, i%60))
                    myHandler.sendMessage(msg)
                } else {
                    i = 0
                }
            }
        }.start()

        buttonStart.setOnClickListener {
            // Initialize and start the timer
            timerText.setText("00:00")
            started = true
        }

        buttonStop.setOnClickListener {
            started = false
        }
    }
}