package kr.ac.dankook.mobile.bspark.assignment_6_3

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {
    private val getResult =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()){ result->
               if(result.resultCode == Activity.RESULT_OK){
                   val value = result.data?.getIntExtra("sumResult", 0)
                   Log.d("DKMobile", "Received Result is " + value.toString())
                   val mainResultView = findViewById<TextView>(R.id.mainResultView)
                   mainResultView.text = "Result is " + value.toString()
               }
            }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("DKMOBILE", "MainActivity onCreate()")
        val intentMain = Intent(this, SubActivity::class.java)

        val num1 = findViewById<EditText>(R.id.num1)
        val num2 = findViewById<EditText>(R.id.num2)
        val calBtn = findViewById<Button>(R.id.calBtn)

        calBtn.setOnClickListener {
            intentMain.putExtra("num1", num1.getText().toString().toInt())
            intentMain.putExtra("num2", num2.getText().toString().toInt())
            // startActivity(intentMain)    : Just converting the screen
            // getResult.launch(intentMain) : Convert the screen in order to get the result
            getResult.launch(intentMain)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("DKMOBILE", "MainActivity onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d("DKMOBILE", "MainActivity onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d("DKMOBILE", "MainActivity onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d("DKMOBILE", "MainActivity onStop()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("DKMOBILE", "MainActivity onDestroy()")
    }
}